"use strict";
exports.__esModule = true;
exports.sendMessage = exports.handler = void 0;
var commons_1 = require("./commons");
var constants_1 = require("./constants");
var AWS = require('aws-sdk');
var SNS = new AWS.SNS({ apiVersion: '2010-03-31' });
/**
 * This function is the entry point for the AWS lambda function as defined in its configuration.
 * @param event : SQSEvent :: Event recieved from the SQS Queue
 */
var handler = function (event) {
    if (event === null || event === void 0 ? void 0 : event.Records.length) {
        try {
            event.Records
                .forEach(function (data) {
                var _a, _b;
                // Putting essential values into an object for easier resusability
                var recordParams = {
                    phoneNumber: ((_b = (_a = data === null || data === void 0 ? void 0 : data.messageAttributes) === null || _a === void 0 ? void 0 : _a.Number) === null || _b === void 0 ? void 0 : _b.stringValue) || '',
                    message: data.body
                };
                if ((0, commons_1.isMessageBodyValid)(recordParams.message) &&
                    (0, commons_1.isPhoneNumberValid)(recordParams.phoneNumber)) {
                    return (0, exports.sendMessage)(recordParams.message, recordParams.phoneNumber);
                }
                throw { message: "Validation failed" };
            });
        }
        catch (e) {
            return e;
        }
    }
    return "Queue is empty";
};
exports.handler = handler;
/**
 * This function performs the action to send the message to the given number received from the SQS queue
 * @param message
 * @param number
 */
var sendMessage = function (message, number) {
    // SNS params; Message is required along with either PhoneNumber / TopicArn
    var params = {
        Message: message,
        PhoneNumber: number,
        MessageAttributes: constants_1.MSG_ATTRIBUTES
    };
    // Core logic for sending message
    var publishTextPromise = SNS.publish(params).promise();
    return publishTextPromise
        .then(function (data) {
        console.log('__Success_Response__', JSON.stringify({
            MessageID: data.MessageId,
            Message: params.Message,
            PhoneNumber: params.PhoneNumber
        })); // Logging to see it in cloudwatch
        return {
            MessageID: data.MessageId,
            Message: params.Message,
            PhoneNumber: params.PhoneNumber
        };
    })["catch"](function (err) {
        console.log('__Error_Response__', JSON.stringify({
            Error: err
        })); // Logging to see it in cloudwatch
        return new Error('Publish failed');
    });
};
exports.sendMessage = sendMessage;
