"use strict";
// import { MSG_LIMIT } from "./constants";
exports.__esModule = true;
exports.isPhoneNumberValid = exports.isMessageBodyValid = void 0;
/**
 * This function validates the messafge body to see if it has exceeded the limit if any
 * @param message
 * @returns bool
 */
var isMessageBodyValid = function (message) {
    /**
     * if (size of message is greater than MSG_LIMIT)
     * return false
     * return true
     */
    return true;
};
exports.isMessageBodyValid = isMessageBodyValid;
/**
 * This function validates the messafge body to see if it has exceeded the limit if any
 * @param message
 * @returns bool
 */
var isPhoneNumberValid = function (phoneNumber) {
    /**
     * if (check if the phone number is valid using a third party package or a private package)
     * return false
     * return true
     */
    return true;
};
exports.isPhoneNumberValid = isPhoneNumberValid;
