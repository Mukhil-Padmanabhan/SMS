"use strict";
exports.__esModule = true;
exports.MSG_ATTRIBUTES = exports.MSG_LIMIT = void 0;
exports.MSG_LIMIT = '';
exports.MSG_ATTRIBUTES = {
    'AWS.SNS.SMS.SenderID': {
        "DataType": 'String',
        "StringValue": 'Lambda-SNS' // This can be altered based on the Subject.
    },
    'AWS.SNS.SMS.SMSType': {
        "DataType": 'String',
        "StringValue": 'Transactional'
    }
};
